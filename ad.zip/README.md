# Apuração 2026

Portal independente para acompanhar a divulgação oficial das Eleições Gerais de 2026. O projeto não contém candidatos ou resultados embutidos: todos os números exibidos vêm dos arquivos públicos EA20 servidos pelo TSE.

## Requisitos

- Node.js 20 ou superior
- A VPS precisa conseguir acessar `https://resultados.tse.jus.br`

## Instalação e execução

```bash
npm install
npm start
```

Abra `http://IP-DA-VPS:3000`. Para usar outra porta: `PORT=8080 npm start`.

## Como funciona

- `server.js` valida UF e cargo em listas permitidas, seleciona o código oficial da eleição e consulta somente o domínio do TSE.
- Os resultados usam o leiaute EA20, com arquivos nacionais para Presidente e estaduais para Presidente por UF e demais cargos.
- O servidor compartilha consultas simultâneas e mantém cache de 25 segundos. Se uma consulta falhar, conserva dados válidos anteriores em memória e os sinaliza como desatualizados.
- O navegador atualiza a cada 60 segundos e também permite atualização manual. A busca filtra nome, número e partido entre os candidatos retornados pelo TSE.
- Não há modo de demonstração, dados simulados, resultado presumido ou chave no frontend.

## Códigos usados

| Cargo | Código | Código de eleição |
|---|---:|---:|
| Presidente | 0001 | 6257 |
| Governador | 0003 | 6259 |
| Senador | 0005 | 6259 |
| Deputado Federal | 0006 | 6259 |
| Deputado Estadual | 0007 | 6259 |
| Deputado Distrital | 0008 | 6259 (DF) |

Exemplos de endpoint interno: `/api/resultados?uf=br&cargo=1`, `/api/resultados?uf=mt&cargo=3`.

## Testes

```bash
npm test
```

Os testes verificam a construção segura das URLs e a leitura dos campos descritos no leiaute EA20. A consulta real depende de conectividade com a CDN do TSE.

## Referências oficiais

- [Portal de resultados do TSE](https://resultados.tse.jus.br/oficial/app/index.html)
- [Informações técnicas da divulgação 2026](https://www.tse.jus.br/eleicoes/informacoes-tecnicas-sobre-a-divulgacao-de-resultados)
- [Especificação EA20 do TSE](https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/divulgacao-de-resultados/tse-ea20-arquivo-de-resultado-unificado)

Este site apenas apresenta dados públicos oficiais e não possui vínculo institucional com o Tribunal Superior Eleitoral.
