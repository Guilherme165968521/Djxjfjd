const UF_LIST = [
  ['br','Brasil'],['ac','Acre'],['al','Alagoas'],['ap','Amapá'],['am','Amazonas'],['ba','Bahia'],['ce','Ceará'],['df','Distrito Federal'],['es','Espírito Santo'],['go','Goiás'],['ma','Maranhão'],['mt','Mato Grosso'],['ms','Mato Grosso do Sul'],['mg','Minas Gerais'],['pa','Pará'],['pb','Paraíba'],['pr','Paraná'],['pe','Pernambuco'],['pi','Piauí'],['rj','Rio de Janeiro'],['rn','Rio Grande do Norte'],['rs','Rio Grande do Sul'],['ro','Rondônia'],['rr','Roraima'],['sc','Santa Catarina'],['sp','São Paulo'],['se','Sergipe'],['to','Tocantins']
];
const OFFICES = [
  {id:'1',name:'Presidente',federal:true}, {id:'3',name:'Governador'}, {id:'5',name:'Senador'}, {id:'6',name:'Deputado Federal'}, {id:'7',name:'Deputado Estadual'}, {id:'8',name:'Deputado Distrital',district:true}
];
const $ = selector => document.querySelector(selector);
const state = { uf:'br', cargo:'1', data:null, loadedKey:null, loading:false, hasData:false, lastUpdateFailed:false };
const intFormat = new Intl.NumberFormat('pt-BR');
const percentFormat = new Intl.NumberFormat('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});

function setupSelectors(){
  $('#uf').innerHTML=UF_LIST.map(([code,name])=>`<option value="${code}">${name}${code==='br'?'':' ('+code.toUpperCase()+')'}</option>`).join('');
  $('#cargo').innerHTML=OFFICES.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
  $('#uf').value='br';$('#cargo').value='1';
  renderUfGrid();
}
function formatNumber(value){return value==null?'—':intFormat.format(value)}
function formatPercent(value){return value==null?'—':`${percentFormat.format(value)}%`}
function summaryCard(label,value,primary=false,detail=''){
  return `<article class="stat-card${primary?' primary':''}"><label>${label}</label><strong>${value}${detail?`<small>${detail}</small>`:''}</strong></article>`;
}
function renderSummary(data){
  const m=data.metrics||{};
  $('#summary').innerHTML=[
    summaryCard('Seções totalizadas',formatPercent(m.sectionsPercent),true),
    summaryCard('Eleitorado',formatNumber(m.electorate)),
    summaryCard('Comparecimento',formatNumber(m.attendance)),
    summaryCard('Abstenção',formatNumber(m.abstention)),
    summaryCard('Votos válidos',formatNumber(m.validVotes)),
    summaryCard('Votos brancos',formatNumber(m.blankVotes)),
    summaryCard('Votos nulos',formatNumber(m.nullVotes)),
    summaryCard('Seções',`${formatNumber(m.sectionsCounted)}${m.totalSections==null?'':`<small> / ${formatNumber(m.totalSections)}</small>`}`)
  ].join('');
  $('#progress-value').textContent=formatPercent(m.sectionsPercent);
  const progress=Math.max(0,Math.min(100,m.sectionsPercent||0));
  $('#progress-ring').style.setProperty('--progress',`${progress*3.6}deg`);
  $('#sections-count').textContent=formatNumber(m.sectionsCounted);
  $('#sections-total').textContent=formatNumber(m.totalSections);
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderCandidates(){
  const data=state.data;
  if(!data)return;
  const query=$('#search').value.trim().toLocaleLowerCase('pt-BR');
  const candidates=(data.candidates||[]).filter(c=>!query||String(c.number||'').includes(query)||`${c.name} ${c.fullName||''} ${c.party||''}`.toLocaleLowerCase('pt-BR').includes(query));
  $('#candidate-count').textContent=`${candidates.length} ${candidates.length===1?'candidato':'candidatos'}`;
  $('#empty-state').classList.toggle('hidden',candidates.length>0);
  $('#candidate-list').innerHTML=candidates.map((candidate,index)=>{
    const percent=candidate.percent??0;
    const width=Math.max(0,Math.min(100,percent));
    const identity=candidate.number?`<div class="candidate-number">${esc(candidate.number)}</div>`:'<div class="candidate-number">—</div>';
    const photo=candidate.photo?`<img class="candidate-photo" src="${esc(candidate.photo)}" alt="Foto oficial de ${esc(candidate.name)}" loading="lazy" data-fallback="${esc(candidate.number||'—')}">`:identity;
    const status=candidate.status?`<span class="candidate-status">${esc(candidate.status)}</span>`:'';
    const metadata=[candidate.party,candidate.coalition].filter(Boolean).join(' · ')||'Dados partidários não informados';
    return `<article class="candidate-row" style="animation-delay:${Math.min(index,12)*25}ms">${photo}<div class="candidate-main"><div class="candidate-name" title="${esc(candidate.name)}">${esc(candidate.name)}${status}</div><div class="candidate-meta">${esc(metadata)}</div><div class="candidate-bar"><i style="width:${width}%"></i></div></div><div class="vote-summary"><strong>${formatNumber(candidate.votes)} votos</strong><span>${formatPercent(candidate.percent)}</span></div></article>`;
  }).join('');
}
function renderUfGrid(){
  $('#uf-grid').innerHTML=UF_LIST.map(([code,name])=>`<button type="button" class="uf-button${code==='br'?' brazil':''}${code===state.uf?' active':''}" data-uf="${code}" aria-label="Ver resultados ${esc(name)}">${code==='br'?'BR':code.toUpperCase()}<small>${code==='br'?'Brasil':esc(name)}</small></button>`).join('');
}
function setBusy(busy){state.loading=busy;$('#refresh').classList.toggle('busy',busy);const live=$('.live-pill');live.innerHTML=state.lastUpdateFailed?'<span class="live-dot"></span> SEM ATUALIZAÇÃO':'<span class="live-dot"></span> AO VIVO';live.classList.toggle('is-stale',state.lastUpdateFailed);$('#update-state').textContent=busy?'Atualizando dados...':(state.hasData?(state.lastUpdateFailed?'Atualização pendente':'● AO VIVO'):'Aguardando dados oficiais');if(busy&&state.data)$('#candidate-list').classList.add('is-loading');else $('#candidate-list').classList.remove('is-loading')}
function showUnavailable(message,url){
  $('#not-available').classList.remove('hidden');$('#official-file').href=url||'https://resultados.tse.jus.br/oficial/app/index.html';
  if(state.hasData){$('#notice').textContent='Não foi possível obter uma nova atualização.';$('#notice').classList.remove('hidden');}
  else $('#candidate-list').innerHTML='';
  if(!state.hasData){$('#summary').innerHTML='';$('#candidate-count').textContent='—';$('#empty-state').classList.add('hidden');}
}
async function loadResults(manual=false){
  if(state.loading)return;
  const requestKey=`${state.uf}:${state.cargo}`;
  if(state.loadedKey!==requestKey){state.data=null;state.hasData=false;state.loadedKey=requestKey;$('#candidate-list').innerHTML='<div class="loading-state"><span class="spinner"></span><span>Consultando os dados oficiais do TSE...</span></div>';$('#summary').innerHTML='';$('#candidate-count').textContent='—';$('#not-available').classList.add('hidden');}
  setBusy(true);$('#notice').classList.add('hidden');$('#not-available').classList.add('hidden');
  const params=new URLSearchParams({uf:state.uf,cargo:state.cargo});
  try{
    const response=await fetch(`/api/resultados?${params}`,{headers:{Accept:'application/json'},cache:'no-store'});
    const result=await response.json();
    if(!response.ok)throw Object.assign(new Error(result.error||'Falha ao consultar o TSE.'),{officialUrl:result.officialUrl});
    state.data=result;state.hasData=true;state.lastUpdateFailed=Boolean(result.stale);
    const d=new Date(result.updatedAt||Date.now());$('#updated-at').textContent=d.toLocaleTimeString('pt-BR',{hour12:false});
    $('#results-title').textContent=`${result.office||OFFICES.find(c=>c.id===state.cargo)?.name||'Resultados'} · ${state.uf==='br'?'Brasil':state.uf.toUpperCase()}`;
    renderSummary(result);renderCandidates();
    $('#notice').classList.toggle('hidden',!result.stale);
    if(result.stale){$('#notice').textContent=result.warning||'Não foi possível obter uma nova atualização.';}
    $('#not-available').classList.add('hidden');
  }catch(error){state.lastUpdateFailed=true;showUnavailable(error.message,error.officialUrl);if(manual&&!state.hasData)$('#update-state').textContent='Tente novamente em instantes';}
  finally{setBusy(false);}
}
function syncFilters(){
  const isPres=state.cargo==='1';
  const district=state.cargo==='8';
  if(district)state.uf='df';
  if(!isPres&&state.uf==='br')state.uf='mt';
  $('#uf').value=state.uf;$('#uf').disabled=district;
  if(district){$('#uf').value='df';state.uf='df';}
  renderUfGrid();$('#search').value='';
  loadResults();
}
$('#uf').addEventListener('change',e=>{state.uf=e.target.value;syncFilters()});
$('#cargo').addEventListener('change',e=>{state.cargo=e.target.value;if(state.cargo!=='1'&&state.uf==='br')state.uf='mt';syncFilters()});
$('#refresh').addEventListener('click',()=>loadResults(true));
$('#search').addEventListener('input',renderCandidates);
$('#candidate-list').addEventListener('error',e=>{const image=e.target.closest('img[data-fallback]');if(!image)return;const fallback=document.createElement('div');fallback.className='candidate-number';fallback.textContent=image.dataset.fallback;image.replaceWith(fallback)},true);
$('#uf-grid').addEventListener('click',e=>{const button=e.target.closest('[data-uf]');if(!button)return;state.uf=button.dataset.uf;syncFilters();$('#painel').scrollIntoView({behavior:'smooth',block:'start'});});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#search').focus()}});
setupSelectors();syncFilters();setInterval(()=>{if(!document.hidden)loadResults()},60_000);
