import test from 'node:test';
import assert from 'node:assert/strict';
import { normalize, tseUrl, ALLOWED_UFS, CARGOS } from '../src/tse.js';

test('URLs são montadas com códigos e sufixos oficiais EA20', () => {
  assert.equal(tseUrl('br','1','6257'),'https://resultados.tse.jus.br/oficial/ele2026/6257/dados/br/br-c0001-e006257-u.json');
  assert.equal(tseUrl('mt','3','6259'),'https://resultados.tse.jus.br/oficial/ele2026/6259/dados/mt/mt-c0003-e006259-u.json');
  assert.equal(tseUrl('mt','6','6259'),'https://resultados.tse.jus.br/oficial/ele2026/6259/dados/mt/mt-c0006-e006259-u.json');
});

test('allowlist inclui todas as UFs e cargos previstos', () => {
  assert.equal(ALLOWED_UFS.size,27);
  assert.deepEqual([...CARGOS.keys()],['1','3','5','6','7','8']);
});

test('normalizador lê campos EA20 sem fabricar valores ausentes', () => {
  const raw={ele:'6259',t:'1',tpabr:'uf',cdabr:'mt',dg:'04/10/2026',hg:'18:10:00',dt:'04/10/2026',ht:'18:09:50',and:'p',tf:'n',carg:[{cd:'0003',nmn:'Governador',agr:[{nm:'Coligação Alfa',par:[{sg:'XY',nm:'Partido Exemplo',cand:[{n:'22',sqcand:'123456',nm:'Nome Civil',nmu:'Nome de urna',e:'n',st:'',vap:'4532',pvap:'51.27'}]}]}]}],s:{ts:'100',st:'50',pst:'50.00'},e:{te:'1000',c:'500',a:'500'},v:{vv:'490',vb:'5',vn:'5'}};
  const out=normalize(raw,{uf:'mt',cargo:'3',election:'6259'});
  assert.equal(out.candidates[0].number,'22');
  assert.equal(out.candidates[0].votes,4532);
  assert.equal(out.candidates[0].percent,51.27);
  assert.equal(out.candidates[0].status,null);
  assert.equal(out.metrics.sectionsPercent,50);
  assert.equal(out.metrics.validVotes,490);
  assert.equal(out.metrics.nullVotes,5);
  assert.equal(out.metrics.totalizedSections??null,null);
  assert.equal(out.candidates[0].photo,'https://resultados.tse.jus.br/oficial/ele2026/6259/fotos/mt/123456.jpeg');
});
