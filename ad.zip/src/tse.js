export const TSE_ROOT = 'https://resultados.tse.jus.br/oficial';
export const ALLOWED_UFS = new Set(['ac','al','ap','am','ba','ce','df','es','go','ma','mt','ms','mg','pa','pb','pr','pe','pi','rj','rn','rs','ro','rr','sc','sp','se','to']);
export const CARGOS = new Map([
  ['1', { label: 'Presidente', election: '6257' }],
  ['3', { label: 'Governador', election: '6259' }],
  ['5', { label: 'Senador', election: '6259' }],
  ['6', { label: 'Deputado Federal', election: '6259' }],
  ['7', { label: 'Deputado Estadual', election: '6259' }],
  ['8', { label: 'Deputado Distrital', election: '6259', only: 'df' }]
]);
function number(value) {
  if (value === undefined || value === null || value === '') return null;
  const parsed = Number(String(value).replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : null;
}
function pad(value, size) { return String(value).padStart(size, '0'); }
export function tseUrl(uf, cargo, election) {
  const scope = cargo === '1' && uf === 'br' ? 'br' : uf;
  const filename = `${scope}-c${pad(cargo, 4)}-e${pad(election, 6)}-u.json`;
  return `${TSE_ROOT}/ele2026/${election}/dados/${scope}/${filename}`;
}
export function normalize(raw, { uf, cargo, election }) {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.carg)) {
    throw new Error('O arquivo recebido não corresponde ao formato EA20 de resultados do TSE.');
  }
  const office = raw.carg.find(item => String(item.cd).padStart(4, '0') === pad(cargo, 4)) || raw.carg[0];
  if (!office) throw new Error('O arquivo oficial ainda não contém dados para este cargo.');
  const candidates = [];
  for (const group of office.agr || []) {
    for (const party of group.par || []) {
      for (const candidate of party.cand || []) {
        candidates.push({
          number: candidate.n == null ? null : String(candidate.n),
          name: candidate.nmu || candidate.nm || 'Nome não informado pelo TSE',
          fullName: candidate.nm || null,
          party: party.sg || null,
          partyName: party.nm || null,
          coalition: group.nm || null,
          votes: number(candidate.vap),
          percent: number(candidate.pvap),
          status: candidate.st || (candidate.e === 's' ? 'Eleito' : null),
          elected: candidate.e === 's',
          photo: candidate.sqcand ? `${TSE_ROOT}/ele2026/${election}/fotos/${uf}/${encodeURIComponent(candidate.sqcand)}.jpeg` : null
        });
      }
    }
  }
  candidates.sort((a, b) => (b.votes ?? -1) - (a.votes ?? -1));
  const sections = raw.s || {};
  const electorate = raw.e || {};
  const votes = raw.v || {};
  return {
    source: 'TSE',
    officialUrl: tseUrl(uf, cargo, election),
    election: String(raw.ele ?? election),
    turn: raw.t ?? null,
    scope: raw.tpabr ?? (uf === 'br' ? 'br' : 'uf'),
    scopeCode: raw.cdabr ?? uf.toUpperCase(),
    generatedDate: raw.dg || null,
    generatedTime: raw.hg || null,
    totalizedDate: raw.dt || null,
    totalizedTime: raw.ht || null,
    progress: raw.and || null,
    totalizationFinal: raw.tf || null,
    mathDecision: raw.md || null,
    office: office.nmn || office.nmm || office.nmf || CARGOS.get(cargo).label,
    metrics: {
      totalSections: number(sections.ts),
      sectionsCounted: number(sections.st),
      sectionsPercent: number(sections.pst),
      electorate: number(electorate.te),
      attendance: number(electorate.c),
      abstention: number(electorate.a),
      validVotes: number(votes.vv),
      blankVotes: number(votes.vb),
      nullVotes: number(votes.vn)
    },
    candidates
  };
}
