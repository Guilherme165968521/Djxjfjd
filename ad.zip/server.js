import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ALLOWED_UFS, CARGOS, normalize, tseUrl } from './src/tse.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT) || 3000;
const TTL_MS = 25_000;
const cache = new Map();
const inFlight = new Map();

async function fetchTse(url) {
  const response = await fetch(url, {
    headers: { 'Accept': 'application/json', 'User-Agent': 'Apuracao2026/1.0 (public-results-viewer)' },
    signal: AbortSignal.timeout(10_000)
  });
  if (!response.ok) {
    const error = new Error(response.status === 404 ? 'O arquivo desta eleição ainda não está disponível no TSE.' : `O TSE respondeu com HTTP ${response.status}.`);
    error.status = response.status;
    throw error;
  }
  return response.json();
}

app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.get('/api/health', (_req, res) => res.json({ ok: true, dataSource: 'Tribunal Superior Eleitoral', cacheSeconds: TTL_MS / 1000 }));
app.get('/api/resultados', async (req, res) => {
  const uf = String(req.query.uf || '').trim().toLowerCase();
  const cargo = String(req.query.cargo || '').trim();
  const cargoInfo = CARGOS.get(cargo);
  if (!(uf === 'br' || ALLOWED_UFS.has(uf))) return res.status(400).json({ error: 'UF inválida. Use br ou uma UF brasileira.' });
  if (!cargoInfo) return res.status(400).json({ error: 'Cargo inválido.' });
  if (cargo === '1' && uf !== 'br' && !ALLOWED_UFS.has(uf)) return res.status(400).json({ error: 'UF inválida para Presidente.' });
  if (cargo !== '1' && uf === 'br') return res.status(400).json({ error: 'Este cargo só possui resultado por UF.' });
  if (cargoInfo.only && uf !== cargoInfo.only) return res.status(400).json({ error: 'Deputado Distrital só se aplica ao Distrito Federal.' });

  const election = cargoInfo.election;
  const key = `${election}:${uf}:${cargo}`;
  const now = Date.now();
  const cached = cache.get(key);
  if (cached && now - cached.savedAt < TTL_MS) {
    return res.json({ ...cached.data, updatedAt: new Date(cached.savedAt).toISOString(), cache: 'hit', stale: false });
  }
  if (inFlight.has(key)) {
    try { return res.json({ ...(await inFlight.get(key)), cache: 'shared', stale: false }); }
    catch { /* handled below with stale data when available */ }
  }
  const url = tseUrl(uf, cargo, election);
  const pending = (async () => {
    const raw = await fetchTse(url);
    const normalized = normalize(raw, { uf, cargo, election });
    const savedAt = Date.now();
    cache.set(key, { data: normalized, savedAt });
    return { ...normalized, updatedAt: new Date(savedAt).toISOString() };
  })();
  inFlight.set(key, pending);
  try {
    const data = await pending;
    return res.json({ ...data, cache: 'miss', stale: false });
  } catch (error) {
    if (cached) return res.json({ ...cached.data, updatedAt: new Date(cached.savedAt).toISOString(), cache: 'stale', stale: true, warning: 'Não foi possível obter uma nova atualização.' });
    const status = error.status === 404 ? 503 : 502;
    return res.status(status).json({ error: error.message || 'Não foi possível consultar os dados oficiais do TSE.', officialUrl: url });
  } finally {
    if (inFlight.get(key) === pending) inFlight.delete(key);
  }
});

app.get('*path', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  app.listen(PORT, '0.0.0.0', () => console.log(`Portal de apuração disponível na porta ${PORT}`));
}
